# Issue Tracking Application

This is an issue Tracking Application implemented for saving and tracking various issues.

## Technology Used

1. Mongo (Database)
2. Express (Nodejs Framework)
3. Angular (Frontend)
4. Node js (Backend)

## Screenshots

**Index page** <br>
![](https://i.imgur.com/V2wFr2k.png)

**Create Page** <br>
![](https://i.imgur.com/8XiWB4p.png)

**Edit Page** <br>
![](https://i.imgur.com/XmPxZW3.png)


